#include <zephyr/kernel.h>
#include <zephyr/sys/printk.h>
#include <zephyr/device.h>
#include <zephyr/devicetree.h>
#include <zephyr/drivers/gpio.h>
#include <stdlib.h>

#include "am2302_sensor.h"

/* nRF52840 DK 보드의 GPIO0 포트, P0.11 고정 */
static const struct device *gpio_dev = DEVICE_DT_GET(DT_NODELABEL(gpio0));
#define DHT_PIN 11

void main(void)
{
    if (!device_is_ready(gpio_dev)) {
        printk("GPIO device not ready!\n");
        return;
    }

    if (dht22_init(gpio_dev, DHT_PIN) != DHT_OK) {
        printk("DHT22 Error\n");
        return;
    }
    printk("DHT22 Init\n");

    struct dht22_data meas;

    while (1) {
        int8_t rc = dht22_read(gpio_dev, DHT_PIN, &meas);
        if (rc == DHT_OK) {
            /* 실제값 = 정수 ÷ 10.0 */
            printk("Temperature: %d.%d°C, Humidity: %d.%d%%\n",
                   meas.temperature / 10,
                   abs(meas.temperature % 10),
                   meas.humidity / 10,
                   meas.humidity % 10);
        } else {
            printk("읽기 에러: %s\n", dht22_errmsg(rc));
        }
        k_msleep(2000);
    }
}

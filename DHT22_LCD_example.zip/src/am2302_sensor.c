#include "am2302_sensor.h"
#include <zephyr/kernel.h>
#include <zephyr/drivers/gpio.h>

static uint32_t last_read_timestamp = 0;

/* 데이터 핀 상태 변화 대기 */
static int await_state(const struct device *dev,
                       gpio_pin_t pin, int level)
{
    uint32_t count = 0;
    /* 변할 때까지 */
    while (gpio_pin_get(dev, pin) != level) {
        if (++count >= DHT_TIMEOUT_US) {
            return DHT_ERROR_TIMEOUT;
        }
        k_busy_wait(1);
    }
    /* 상태 유지 시간 측정 (not used, but consume) */
    count = 0;
    while (gpio_pin_get(dev, pin) == level) {
        if (++count >= DHT_TIMEOUT_US) {
            return DHT_ERROR_TIMEOUT;
        }
        k_busy_wait(1);
    }
    return 0;
}

/* 5바이트 읽기 */
static int read_bytes(const struct device *dev,
                      gpio_pin_t pin,
                      uint8_t *buf, size_t len)
{
    for (size_t i = 0; i < len; i++) {
        for (int b = 0; b < 8; b++) {
            if (await_state(dev, pin, 0) < 0) {
                return DHT_ERROR_TIMEOUT;
            }
            /* HIGH 길이 측정 */
            uint32_t cnt = 0;
            while (gpio_pin_get(dev, pin)) {
                if (++cnt >= DHT_TIMEOUT_US) {
                    return DHT_ERROR_TIMEOUT;
                }
                k_busy_wait(1);
            }
            buf[i] <<= 1;
            if (cnt > 28) {
                buf[i] |= 1;
            }
        }
    }
    return DHT_OK;
}

int dht22_init(const struct device *gpio_dev, gpio_pin_t pin)
{
    /* 풀업 입력 모드 */
    gpio_pin_configure(gpio_dev, pin,
                       GPIO_INPUT | GPIO_PULL_UP);
    /* 최초 안정화 대기 */
    k_msleep(DHT_MIN_INTERVAL_MS);
    return DHT_OK;
}

int8_t dht22_read(const struct device *gpio_dev,
                  gpio_pin_t pin,
                  struct dht22_data *out)
{
    uint32_t now = k_uptime_get_32();
    if (now - last_read_timestamp < DHT_MIN_INTERVAL_MS) {
        return DHT_ERROR_FREQUENCY;
    }
    last_read_timestamp = now;

    /* === 스타트 신호 === */
    gpio_pin_configure(gpio_dev, pin, GPIO_OUTPUT);
    gpio_pin_set(gpio_dev, pin, 0);
    k_busy_wait(DHT_START_US);
    gpio_pin_set(gpio_dev, pin, 1);
    gpio_pin_configure(gpio_dev, pin,
                       GPIO_INPUT | GPIO_PULL_UP);

    /* === ACK 대기 === */
    if (await_state(gpio_dev, pin, 0) < 0 ||
        await_state(gpio_dev, pin, 1) < 0) {
        return DHT_ERROR_TIMEOUT;
    }

    /* === 5바이트 읽기 === */
    uint8_t data[5] = {0};
    int ret = read_bytes(gpio_dev, pin, data, 5);
    if (ret < 0) {
        return ret;
    }

    /* === 체크섬 === */
    uint8_t sum = data[0] + data[1] + data[2] + data[3];
    if (data[4] != sum) {
        return DHT_ERROR_CHECKSUM;
    }

    /* 결과 저장 (10배 정수) */
    out->humidity    = (data[0] << 8) | data[1];
    int16_t t_raw    = ((data[2] & 0x7F) << 8) | data[3];
    out->temperature = (data[2] & 0x80) ? -t_raw : t_raw;

    return DHT_OK;
}

const char *dht22_errmsg(int8_t err)
{
    switch (err) {
    case DHT_OK:             return "OK";
    case DHT_ERROR_CHECKSUM: return "Checksum Error";
    case DHT_ERROR_TIMEOUT:  return "Timeout";
    case DHT_ERROR_FREQUENCY:return "Too Fast";
    default:                 return "Unknown";
    }
}

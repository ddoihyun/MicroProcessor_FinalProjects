#ifndef AM2302_SENSOR_H
#define AM2302_SENSOR_H

#include <zephyr/types.h>
#include <stdbool.h>
#include <zephyr/drivers/gpio.h>

/* 시간 상수 */
#define DHT_TIMEOUT_US       100U    /* 100 µs */
#define DHT_START_US        1200U    /* 스타트 신호 길이 (µs) */
#define DHT_MIN_INTERVAL_MS 2000U    /* 최소 읽기 간격 (ms) */

/* 에러 코드 */
enum {
    DHT_OK = 0,
    DHT_ERROR_CHECKSUM   = -1,
    DHT_ERROR_TIMEOUT    = -2,
    DHT_ERROR_FREQUENCY  = -3,
};

struct dht22_data {
    uint16_t humidity;    /* 10배율 정수: 실제습도×10 */
    int16_t  temperature; /* 10배율 정수: 실제온도×10 */
};

/**
 * @brief  센서 초기화 (풀업, 최초 딜레이)
 * @param  gpio_dev : DT로 얻은 gpio 디바이스 포인터
 * @param  pin      : 데이터 핀 번호 (0–31)
 * @return DHT_OK (0) 또는 에러
 */
int dht22_init(const struct device *gpio_dev, gpio_pin_t pin);

/**
 * @brief  센서로부터 온습도 읽기
 * @param  gpio_dev : DT로 얻은 gpio 디바이스 포인터
 * @param  pin      : 데이터 핀 번호
 * @param  out      : 결과를 저장할 구조체 포인터
 * @return DHT_OK 또는 에러코드
 */
int8_t dht22_read(const struct device *gpio_dev,
                  gpio_pin_t pin,
                  struct dht22_data *out);

/**
 * @brief  에러코드 → 문자열 변환
 */
const char *dht22_errmsg(int8_t err);

#endif /* AM2302_SENSOR_H */
